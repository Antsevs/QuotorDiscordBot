package events;


import java.util.HashMap;
import java.util.Map;

//import java.util.HashMap;
//import java.util.Map;

import org.jetbrains.annotations.NotNull;

import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;


public class interactionEventListener extends ListenerAdapter {
	
	public final Map<String, String> channelMap = new HashMap<>();
	private String currentServerID;
	
	@Override
	public void onSlashCommandInteraction(@NotNull SlashCommandInteractionEvent event) {
		
		super.onSlashCommandInteraction(event);
		
		if(event.getName().equals("setchannel")) {
			
			OptionMapping option = event.getOption("channel");
			if(option == null) {
				event.reply("There was no channel provided").queue();
				return;
			}
			
			String channelName = option.getAsString();
			currentServerID = event.getGuild().getId();
			
			channelMap.put(currentServerID,  channelName);
			
			event.reply("Your selected channel is " + channelName).queue();
			
		}
	}
	
	public String getChannelName(String serverID) {
		return channelMap.get(serverID);
	}
	
	public String getCurrentServerID() {
		return currentServerID;
	}
	
}
	

