package javaQuotorDiscordBot;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.security.auth.login.LoginException;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.session.ReadyEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.requests.GatewayIntent;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import events.interactionEventListener;

public class Bot extends ListenerAdapter {
	
	private static final Map<Long, String> channelPref = new HashMap<>();
	
	public static void main(String[] args) throws LoginException, InterruptedException{
		
		final String token = "OTE2MDM4MTYxNzE5NzYzMDM1.G6xAH-._C9_DbyGQLXA3leUcXz3MqoaC7cUDGeHR4xuV8";
		
		JDA jda = JDABuilder.createDefault(token)

				.enableIntents(GatewayIntent.GUILD_MESSAGES, GatewayIntent.DIRECT_MESSAGES, GatewayIntent.MESSAGE_CONTENT)
				.addEventListeners(new Bot(), new interactionEventListener())
				.build();
		
		jda.getPresence().setActivity(Activity.watching("Ant code"));
		
		jda.upsertCommand("setchannel", "Sets the preferred channel for Quotor").setGuildOnly(false)
			.addOption(OptionType.STRING, "channel", "preferred channel for Quotor", true)
			.queue();
		
		schedulePost(jda);
	}
	
	@Override
	public void onReady(ReadyEvent event) {
		System.out.println("The bot is ready");
		System.out.println(event.getJDA().getToken());
		//below allows for immediate grab and post of the word of the day
		event.getJDA().getGuilds().forEach(guild -> postWOD(guild));
	}
	
	public void onSlashCommand(SlashCommandInteractionEvent event) {
		if(event.getName().equals("setchannel")) {
			OptionMapping userOpt = event.getOption("channel");
			if(userOpt != null && userOpt.getType() == OptionType.STRING) {
				String channelName = userOpt.getAsString();
				channelPref.put(event.getGuild().getIdLong(), channelName);
				
				event.reply("Channel set to **" + channelName + "**").queue();
			} else {
				event.reply("Gimme a channel name").queue();
			}
		}

	}
	
	public static void postWOD(Guild guild) {

		String wordOfTheDay = getWordOfTheDay(); //implement web scraping
		String channelName = "👂word-of-the-day👂";//set the channel for post
		//check if the channel exists in the server
		List<TextChannel> channels = guild.getTextChannelsByName(channelName, true);
		if(channels.isEmpty() || channels.get(0) == null) {
			System.err.println("Error 404: Channel Not Found in guild " + guild.getName());
		} else {
			TextChannel channel = channels.get(0);
			channel.sendMessage("The word of the day is" + wordOfTheDay).queue();
		}

	}
	

	//post every 24 hours
	public static void schedulePost(JDA jda) {
		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
		scheduler.scheduleAtFixedRate(() -> {
            jda.getGuilds().forEach(guild -> postWOD(guild));
        }, 0, 24, TimeUnit.HOURS);
    }
	
	
	//web scraping
	private static String getWordOfTheDay() {
		try {
			Document doc = Jsoup.connect("httpS://www.merriam-webster.com/word-of-the-day").get();
			
			Connection.Response response = Jsoup.connect("httpS://www.merriam-webster.com/word-of-the-day").execute();

		    // Log HTTP response code
		    int statusCode = response.statusCode();
		    System.out.println("HTTP Status Code: " + statusCode);
			Element wordElement = doc.selectFirst(".word-header .word-and-pronunciation .word-header-txt");
			Element definitionElement = doc.selectFirst(".wod-article-container .wod-definition-container p");
			
			String wordOfTheDay = wordElement.text();
			String definition = definitionElement.text();
			
			//post message formatted for discord
			return " **" + wordOfTheDay + "**" + " - " + definition;
		} catch (IOException e) {
			e.printStackTrace();
			return "Could not find word of the day";
		}
	}
}